package org.cvtc.shapes;

// Represents a 3D cuboid shape
public class Cuboid {

	// cuboid width
	private float width = 0.0f;
	
	// cuboid height
	private float height = 0.0f;
	
	// cuboid depth
	private float depth = 0.0f;
	
	// *** getters and setters for cuboid variables
	private float getWidth() {
		return width;
	}
	
	private void setWidth(float width) {
		this.width = width;
	}
	
	private float getHeight() {
		return height;
	}
	
	private void setHeight(float height) {
		this.height = height;
	}
	
	private float getDepth() {
		return depth;
	}
	
	private void setDepth(float depth) {
		this.depth = depth;
	}
	// ***
	
	// Initializes a new instance of a Cuboid
	public Cuboid(float width, float height, float depth) {
		
		// TODO Consider checking for negative arguments here (again height can't be negative)
		// Set the dimensions of this Cuboid instance
		setWidth(width);
		setHeight(height);
		setDepth(depth);
	}
	
	// Calculates and returns the surface area for this Cuboid instance.
	public float getSurfaceArea() {
		
		// surface area = l * w * h * pi
		return getWidth() * getDepth() * getHeight() * (float)Math.PI;
	}

	// Calculates and returns the volume for this Cuboid instance
	public float getVolume() {
		// v = l * w * h
		return (getWidth() * getDepth() * getHeight());
	}

}


//Represents a 3D cylinder shape
public class Cuboid {

	// cylinder radius
	private float radius = 0.0f;
	
	// cylinder height
	private float height = 0.0f;
	
	// *** getters and setters for cylinder variables
	private float getRadius() {
		return radius;
	}
	
	private void setRadius(float width) {
		this.radius = radius;
	}
	
	private float getHeight() {
		return height;
	}
	
	private void setHeight(float height) {
		this.height = height;
	}
	// ***
	
	// Initializes a new instance of a cylinder
	public Cuboid(float radius, float height) {
		
		// TODO Consider checking for negative arguments here (again height can't be negative)
		// Set the dimensions of this cylinder instance
		setWidth(radius);
		setHeight(height);
	}
	
	// Calculates and returns the surface area for this cylinder instance.
	public float getSurfaceArea() {
		
		// area = 2 * pi * r *h + 2 * pi * r^2
		return (2 * (float)Math.PI * getRadius() * getHeight()) + (2 * (float)Math.PI * (getRadius() ^ 2));
	}

	// Calculates and returns the volume for this cylinder instance
	public float getVolume() {
		// volume	=	pi * r^2 * h 
		return ((float)Math.PI * (getRadius() ^ 2) * getHeight());
	}

}

//Represents a 3D sphere shape
public class Cuboid {

	// sphere radius
	private float radius = 0.0f;
	
	// *** getters and setters for sphere variables
	private float getRadius() {
		return radius;
	}
	
	private void setRadius(float width) {
		this.radius = radius;
	}
	// ***
	
	// Initializes a new instance of a sphere
	public Cuboid(float radius, float height) {
		
		// TODO Consider checking for negative arguments here (again height can't be negative)
		// Set the dimensions of this sphere instance
		setWidth(radius);
	}
	
	// Calculates and returns the surface area for this sphere instance.
	public float getSurfaceArea() {
		
		// area = 4 * pi * r^2
		return (4 * (float)Math.PI * (getRadius()^ 2));
	}

	// Calculates and returns the volume for this sphere instance
	public float getVolume() {
		// volume	=	volume	= 4/3 * pi * r^3  
		return ((4 / 3)(float)Math.PI * (getRadius() ^ 2));
	}

}