package org.cvtc.shapes;

public class ShapeTest {

	public static void main(String[] args) {
		Shape cuboid = null;
		
		try {
			cuboid = new Cuboid(4, 5, 6);
			cuboid.render();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
