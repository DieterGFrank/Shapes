package org.cvtc.shapes;

import javax.swing.JOptionPane;

// Represents a 3D cuboid shape
public class Cuboid extends Shape {

	// cuboid width
	private float width = 0.0f;
	
	// cuboid height
	private float height = 0.0f;
	
	// cuboid depth
	private float depth = 0.0f;
	
	// *** getters and setters for cuboid variables
	private float getWidth() {
		return width;
	}
	
	private void setWidth(float width) {
		this.width = width;
	}
	
	private float getHeight() {
		return height;
	}
	
	private void setHeight(float height) {
		this.height = height;
	}
	
	private float getDepth() {
		return depth;
	}
	
	private void setDepth(float depth) {
		this.depth = depth;
	}
	// ***
	
	// Initializes a new instance of a Cuboid
	public Cuboid(float width, float height, float depth) throws Exception {
		
		if (width < 0.0f) {
			throw new Exception("No negative numbers.");
		} else if (height < 0.0f) {
			throw new Exception("No negative numbers.");
		} else if (depth < 0.0f) {
			throw new Exception("No negative numbers.");
		}
		
		// Set the dimensions of this Cuboid instance
		setWidth(width);
		setHeight(height);
		setDepth(depth);
	}
	
	// Calculates and returns the surface area for this Cuboid instance.
	public float getSurfaceArea() {
		
		// surface area = l * w * h * pi
		return getWidth() * getDepth() * getHeight() * (float)Math.PI;
	}

	// Calculates and returns the volume for this Cuboid instance
	public float getVolume() {
		// v = l * w * h
		return (getWidth() * getDepth() * getHeight());
	}
	
	public void render() {
		
		String title = "Cuboid Information";
		
		String message = "Cuboid Information:\r\n" +
						"\tWidth is " + getWidth() + "\r\n" +
						"\tHeight is " + getHeight() + "\r\n" +
						"\tDepth is " + getDepth() + "\r\n" +
						"\tSurface area is " + getSurfaceArea() + "\r\n" +
						"\tVolume is " + getVolume() + "\r\n";
		
		JOptionPane.showMessageDialog(null, message, title, 1);
	}

}

