package org.cvtc.shapes;

import javax.swing.JOptionPane;

//Represents a 3D cylinder shape
public class Cylinder extends Shape {

	// cylinder radius
	private float radius = 0.0f;
	
	// cylinder height
	private float height = 0.0f;
	
	// *** getters and setters for cylinder variables
	private float getRadius() {
		return radius;
	}
	
	private void setRadius(float radius) {
		this.radius = radius;
	}
	
	private float getHeight() {
		return height;
	}
	
	private void setHeight(float height) {
		this.height = height;
	}
	// ***
	
	// Initializes a new instance of a cylinder
	public Cylinder(float radius, float height) throws Exception {
		
		if (radius < 0.0f) {
			throw new Exception("No negative numbers.");
		} else if (height < 0.0f) {
			throw new Exception("No negative numbers.");
		}
		
		// Set the dimensions of this cylinder instance
		setRadius(radius);
		setHeight(height);
	}
	
	// Calculates and returns the surface area for this cylinder instance.
	public float getSurfaceArea() {
		
		// area = 2 * pi * r *h + 2 * pi * r^2
		return (2 * (float)Math.PI * getRadius() * getHeight()) +
				(2 * (float)Math.PI * (getRadius() * getRadius()));
	}

	// Calculates and returns the volume for this cylinder instance
	public float getVolume() {
		// volume	=	pi * r^2 * h 
		return ((float)Math.PI * (getRadius() * getRadius()) * getHeight());
	}
	
	public void render() {
		
		String title = "Cuboid Information";
		
		String message = "Cuboid Information:\r\n" +
						"\tWidth is " + getRadius() + "\r\n" +
						"\tHeight is " + getHeight() + "\r\n" +
						"\tSurface area is " + getSurfaceArea() + "\r\n" +
						"\tVolume is " + getVolume() + "\r\n";
		
		JOptionPane.showMessageDialog(null, message, title, 1);
	}

}