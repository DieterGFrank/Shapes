package org.cvtc.shapes;

public abstract class Shape {
	public abstract float getSurfaceArea();
	public abstract float getVolume();
	public abstract void render();
}
