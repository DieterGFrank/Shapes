package org.cvtc.shapes;

import javax.swing.JOptionPane;

//Represents a 3D sphere shape
public class Sphere extends Shape {

	// sphere radius
	private float radius = 0.0f;
	
	// *** getters and setters for sphere variables
	private float getRadius() {
		return radius;
	}
	
	private void setRadius(float radius) {
		this.radius = radius;
	}

	
	// Initializes a new instance of a sphere
	public Sphere(float radius) throws Exception{
		
		if (radius < 0.0f) {
			throw new Exception("No negative numbers.");
		}
		
		// Set the dimensions of this sphere instance
		setRadius(radius);
	}
	
	// Calculates and returns the surface area for this sphere instance.
	public float getSurfaceArea() {
		
		// area = 4 * pi * r^2
		return (4 * (float)Math.PI * (getRadius() * getRadius()));
	}

	// Calculates and returns the volume for this sphere instance
	public float getVolume() {
		// volume	=	volume	= 4/3 * pi * r^3  
		return (float)((4.0f / 3.0f) * Math.PI * (getRadius() * getRadius() * getRadius()));
	}
	
	public void render() {
		
		String title = "Cuboid Information";
		
		String message = "Cuboid Information:\r\n" +
						"\tWidth is " + getRadius() + "\r\n" +
						"\tSurface area is " + getSurfaceArea() + "\r\n" +
						"\tVolume is " + getVolume() + "\r\n";
		
		JOptionPane.showMessageDialog(null, message, title, 1);
	}

}