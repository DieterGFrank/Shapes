package org.cvtc.tests;

import static org.junit.Assert.*;

import org.cvtc.shapes.*;
import org.junit.Test;

public class SphereUnitTests {

	@Test
	public void getVolume_Radius1_Returns4_19() throws Exception {
		// 1. Arrange
		Shape sphere = new Sphere(1);
		float expected = 4.19f;
		
		// 2. Act
		float actual = sphere.getVolume();
		
		// 3. Assert
		assertEquals(expected, actual, 0.0001f);
	}
	
	@Test(expected = Exception.class)
	public void sphere_NegativeRadius_ThrowsException() throws Exception {
		// 1. Arrange, act, assert
		Shape sphere = new Sphere(-1);
	}

}
