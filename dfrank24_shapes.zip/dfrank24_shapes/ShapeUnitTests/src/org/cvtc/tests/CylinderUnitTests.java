package org.cvtc.tests;

import static org.junit.Assert.*;

import org.cvtc.shapes.*;
import org.junit.Test;

public class CylinderUnitTests {

	@Test
	public void getVolume_Radius1_Height2_Returns4_19() throws Exception {
		// 1. Arrange
		Shape cylinder = new Cylinder(1, 2);
		float expected = 4.19f;
		
		// 2. Act
		float actual = cylinder.getVolume();
		
		// 3. Assert
		assertEquals(expected, actual, 0.0001f);
	}
	
	@Test(expected = Exception.class)
	public void cylinder_NegatieRadius_ThrowsException() throws Exception {
		// 1. Arrange, act, assert
		Shape cylinder = new Cylinder(-1, 2);
	}
	
	@Test(expected = Exception.class)
	public void cylinder_NegativeHeight_ThrowsException() throws Exception {
		// 1. Arrange, act, assert
		Shape cylinder = new Cylinder(1, -2);
	}

}