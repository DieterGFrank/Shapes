package org.cvtc.tests;

import static org.junit.Assert.*;

import org.cvtc.shapes.*;
import org.junit.Test;

public class CuboidUnitTests {

	@Test
	public void getVolume_Width1Height2Depth3_Returns6() throws Exception {
		// 1. Arrange
		Shape cuboid = new Cuboid(1, 2, 3);
		float expected = 6.0f;
		
		// 2. Act
		float actual = cuboid.getVolume();
		
		// 3. Assert
		assertEquals(expected, actual, 0.0001f);
	}
	
	@Test(expected = Exception.class)
	public void cuboid_NegativeWidth_ThrowsException() throws Exception {
		// 1. Arrange, act, assert
		Shape cuboid = new Cuboid(-1, 2, 3);
	}
	
	@Test(expected = Exception.class)
	public void cuboid_NegativeHeight_ThrowsException() throws Exception {
		// 1. Arrange, act, assert
		Shape cuboid = new Cuboid(1, -2, 3);
	}
	
	@Test(expected = Exception.class)
	public void cuboid_NegativeDepth_ThrowsException() throws Exception {
		// 1. Arrange, act, assert
		Shape cuboid = new Cuboid(1, 2, -3);
	}
}
